<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="refresh" content="0;url=main/index.php">
    <title>GSS TECH</title>
    <script language="javascript">
        window.location.href = "main/login.php"
    </script>
</head>
<body>
<a href="main/login.php"></a>
</body>
</html>
