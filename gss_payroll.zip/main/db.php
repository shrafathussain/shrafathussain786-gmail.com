<?php 
$conn = new PDO('mysql:host=localhost; dbname=gss_payroll','root', ''); 
?>