<?php
// configuration
include('../connect.php');

// new data
$id = $_POST['id'];

$a = $_POST['date'];
$b = $_POST['empid'];
$c = $_POST['amount'];

$d = $_POST['narr'];
// query
$sql = "UPDATE advance 
        SET date=?, adv_amount=?, narration=?
		WHERE adv_id=?";
$q = $db->prepare($sql);
$q->execute(array($a,$c,$d,$id));
echo "<script>alert('Successfully Updated!!!'); window.location='advance.php'</script>";

?>