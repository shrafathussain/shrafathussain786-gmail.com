<?php
//insert.php
$connect = mysqli_connect("localhost", "root", "", "gss_payroll");
if(isset($_POST["emp_id"]))
{
 $emp_id = $_POST["emp_id"];
 $emp_status = $_POST["emp_status"];
 $date = date('Y-m-d H:i:s');

 $query = '';
 for($count = 0; $count<count($emp_id); $count++)
 {
  $item_name_clean = mysqli_real_escape_string($connect, $emp_id[$count]);
  $item_code_clean = mysqli_real_escape_string($connect, $emp_status[$count]);
  
  if($item_name_clean != '' && $item_code_clean != '')
  {
   $query .= '
   INSERT INTO attendance(date,emp_id, status) 
   VALUES( "'.$date.'","'.$item_name_clean.'", "'.$item_code_clean.'"); 
   ';
  }
 }
 if($query != '')
 {
  if(mysqli_multi_query($connect, $query))
  {
   echo 'Item Data Inserted';
  }
  
  else
  {
   echo 'Error';
  }
 }
 else
 {
  echo 'All Fields are Required';
 }
}
?>
