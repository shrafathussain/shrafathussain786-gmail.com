<?php
	include('../connect.php');
	$id=$_GET['id'];
	$u=$_GET['user'];

	
	$result = $db->prepare("DELETE FROM advance WHERE adv_id= :memid");
	$result->bindParam(':memid', $id);
	$result->execute();
	echo "<script>alert('Successfully Deleted!!!'); window.location='advance.php'</script>";
	if($u == 'admin'){
		///do save processing
		$result = $db->prepare("DELETE FROM advance WHERE adv_id= :memid");
		$result->bindParam(':memid', $id);
		$result->execute();
		
	}
	else if($u == 'user'){
		# do something here to delete
		echo " u r no authorized";
	  
		
	  
	
	}
?>