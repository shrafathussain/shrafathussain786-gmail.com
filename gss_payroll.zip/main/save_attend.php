<?php

    require_once ('db.php');



   
    $num = array("2","4","6");
    $numEncoded = json_encode($num);
    $st = array("a", "p", "p");
    $stEncoded = json_encode($st);
   


    $sql = "INSERT INTO attendance (emp_id,status) VALUES (:a,:b)";
    $q = $db->prepare($sql);
    $q->execute(array(':a'=>$numEncoded,':b'=>$stEncoded));

    echo "<script>alert('Successfully Added!!!'); window.location='index.php'</script>";
           

?>