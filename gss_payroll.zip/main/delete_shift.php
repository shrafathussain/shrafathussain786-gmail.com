<?php
	include('../connect.php');
	$id=$_GET['id'];
	$u=$_GET['user'];

	
	$result = $db->prepare("DELETE FROM shift WHERE shift_id= :memid");
	$result->bindParam(':memid', $id);
	$result->execute();
	header("location:   shift.php");
	
?>