<?php
// configuration
include('../connect.php');

// new data
$id = $_POST['id'];



$a = $_POST['name'];


// query
$sql = "UPDATE designation 
        SET desg_name=?
		WHERE desig_id=?";
$q = $db->prepare($sql);
$q->execute(array($a,$id));
echo "<script>alert('Successfully Updated!!!'); window.location='position.php'</script>";

?>