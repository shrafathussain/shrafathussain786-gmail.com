<?php

require_once ('db.php');

if (isset($_POST['Submit'])) {
// echo "";
// }else{
// $file=$_FILES['image']['tmp_name'];
// $image = $_FILES["image"] ["name"];
// $image_name= addslashes($_FILES['image']['name']);
// $size = $_FILES["image"] ["size"];
// $error = $_FILES["image"] ["error"];
// 
// if ($error > 0){
// die("Error uploading file! Code $error.");
// }else{
// 	if($size > 10000000) //conditions for the file
// 	{
// 	die("Format is not allowed or file size is too big!");
// 	}
// 	
// else
// 	{
move_uploaded_file($_FILES["photo"]["tmp_name"],"uploads/" . $_FILES["photo"]["name"]);			
$location=$_FILES["photo"]["name"];

$id = $_POST['id'];
$rdate = $_POST['rdate'];
$name = $_POST['name'];
$gender = $_POST['gender'];
$mobile = $_POST['mobileno'];
$cnic = $_POST['cnic'];
$address = $_POST['address'];


$shift_id = $_POST['shift'];
$dep_id = $_POST['department'];
$job_id = $_POST['job'];
$salary = $_POST['salary'];


$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$sql = "INSERT INTO employee (emp_code, join_date, emp_name,gender,contact,cnic,address,shift_id,dep_id,job_id,salary,photo)
VALUES ('$id','$rdate', '$name', '$gender' , '$mobile' , '$cnic' , '$address' , '$shift_id' , '$dep_id' , '$job_id' , '$salary' , '$location')";

$conn->exec($sql);
//insert to other tble

echo "<script>alert('Successfully Added!!!'); window.location='employee.php'</script>";
// }
}
// }
?>