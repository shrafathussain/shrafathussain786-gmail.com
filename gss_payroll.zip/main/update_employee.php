<?php
// configuration
include('../connect.php');

// new data
$id = $_POST['id'];

$a = $_POST['date'];

$b = $_POST['name'];
$c = $_POST['contact'];
$d = $_POST['cnic'];
$e = $_POST['address'];
$f = $_POST['salary'];


// query
$sql = "UPDATE employee 
        SET emp_name=?, contact=?, cnic=?, address=?, salary=?
		WHERE emp_id=?";
$q = $db->prepare($sql);
$q->execute(array($b,$c,$d,$e,$f,$id));
echo "<script>alert('Successfully Updated!!!'); window.location='employee.php'</script>";

?>