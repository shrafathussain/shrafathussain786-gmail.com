<?php
$firstquarter = array(1 => 'January', 'February', 'March');
print_r($firstquarter);
?>
<html>
<body>

<table>

<tr>
    <th>1</th>
    <th>2</th>
    <th>3</th>
</tr>

<?php 

   
?>

</table>
</body>
</html>