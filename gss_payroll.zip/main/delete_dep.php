<?php
	include('../connect.php');
	$id=$_GET['id'];
	$u=$_GET['user'];

	
	$result = $db->prepare("DELETE FROM department WHERE dep_id= :memid");
	$result->bindParam(':memid', $id);
	$result->execute();
	header("location:   department.php");
	
?>