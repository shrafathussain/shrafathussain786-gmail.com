<?php
// configuration
include('../connect.php');

// new data
$id = $_POST['id'];
$a = $_POST['timein'];
$b = $_POST['timeout'];



// query
$sql = "UPDATE shift 
        SET time_in=? , time_out=?
		WHERE shift_id=?";
$q = $db->prepare($sql);
$q->execute(array($a,$b,$id));
echo "<script>alert('Successfully Updated!!!'); window.location='shift.php'</script>";

?>