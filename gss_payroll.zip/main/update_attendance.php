<?php
// configuration
include('../connect.php');

// new data
$id = $_POST['id'];

$a = $_POST['date'];

$c = $_POST['status'];


// query
$sql = "UPDATE attendance 
        SET date=?, status=?
		WHERE att_id=?";
$q = $db->prepare($sql);
$q->execute(array($a,$c,$id));
echo "<script>alert('Successfully Updated!!!'); window.location='view_attendance.php'</script>";

?>