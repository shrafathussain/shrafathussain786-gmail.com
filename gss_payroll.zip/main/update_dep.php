<?php
// configuration
include('../connect.php');

// new data
$id = $_POST['id'];



$a = $_POST['d_name'];


// query
$sql = "UPDATE department 
        SET dep_name=?
		WHERE dep_id=?";
$q = $db->prepare($sql);
$q->execute(array($a,$id));
echo "<script>alert('Successfully Updated!!!'); window.location='department.php'</script>";

?>