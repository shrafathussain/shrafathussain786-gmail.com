<?php
	session_start();
	include '../conn.php';

	if(!isset($_SESSION['username']) || trim($_SESSION['username']) == ''){
		header('location: ../index.php');
	}

	$sql = "SELECT * FROM users WHERE username = '".$_SESSION['username']."'";
	$query = $conn->query($sql);
	$user = $query->fetch_assoc();
	
?>