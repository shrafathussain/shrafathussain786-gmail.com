<?php
$nameArr = json_decode($_POST["name"]);
$ageArr = json_decode($_POST["age"]);
$con=mysqli_connect("localhost","root","","gss_payroll");
/* Check connection */
if (mysqli_connect_errno())
{
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
for ($i = 0; $i < count($nameArr); $i++) {

    if(($nameArr[$i] != "")){   /* not allowing empty values and the row which has been removed. */
    $sql="INSERT INTO attendance (emp_id, status)
VALUES
('$nameArr[$i]','$ageArr[$i]')";
    if (!mysqli_query($con,$sql))
    {
        die('Error: ' . mysqli_error($con));
    }
    }
}
Print  "Data added Successfully !";
mysqli_close($con);
?>

